/*
 * AdaptiveLights_AutomaticBrakes.c
 *
 * Created: 5/6/2023 10:05:00 PM
 * Author : Mai
 */ 

#define F_CPU 16000000UL
#include <avr/io.h>
#include <util/delay.h>
#include <stdlib.h>
#include <avr/interrupt.h>
#include <stdio.h>			/* Include std. library file */
#include <string.h>
#include <math.h>

/* Automatic Braking System */
#define  Trigger_pin	PA0	/* Trigger pin */
int TimerOverflow = 0;
volatile uint8_t Direction = 0;
/* NOT TO BE USED */
void ADC_Init()				/* ADC Initialization function */
{
	DDRA = 0x01;			/* Make ADC port as input */
	ADCSRA = 0x87;			/* Enable ADC, with freq/128 */
	ADMUX = 0x40;			/* Vref: Avcc, ADC channel: 0 */
}
int ADC_Read(char channel)		/* ADC Read function */
{
	ADMUX = 0x40 | (channel & 0x07);/* set input channel to read */
	ADCSRA |= (1<<ADSC);		    /* Start ADC conversion */
	while (!(ADCSRA & (1<<ADIF)));	/* Wait until end of conversion */
	ADCSRA |= (1<<ADIF);		    /* Clear interrupt flag */
	_delay_ms(1);			        /* Wait a little bit */
	return ADCW;			        /* Return ADC word */
}
ISR(INT0_vect)
{
	Direction = ~Direction;		/* Toggle Direction */
	_delay_ms(50);			/* Software de-bouncing control delay */
}

ISR(TIMER1_OVF_vect)
{
	TimerOverflow++;	/* Increment Timer Overflow count */
}

/* LED Intensity */
void PWM_init()
{
	/*set fast PWM mode with non-inverted output*/
	TCCR2 = (1<<WGM00) | (1<<WGM01) | (1<<COM01) | (1<<CS00);
	DDRD|=(1<<PD7);  /*set OC2 pin as output*/
}

int main(void)
{	
	/* Automatic Braking System */
	DDRD &= ~(1<<PD2);		/* Make INT0 pin as Input */	
	DDRA = 0x01;		    /* Make trigger pin as output */
	DDRB |= (1<<PB3);		/* Make OC0 pin as Output */
	DDRC = 0xFF;			/* Make PORTC as Output Port for DC Motor Input Pins */
	PORTC = 0x00;
	PORTD |= (1<<PD2);		/* Turn on Pull-up */
	
	GICR = (1<<INT0);		/* Enable INT0*/
	MCUCR = ((1<<ISC00)|(1<<ISC01));/* Trigger INT0 on Rising Edge triggered */
	sei();			    	/* Enable Global Interrupt */
	
	TCNT0 = 0;			    /* Set timer0 count zero */
	TCCR0 = (1<<WGM00)|(1<<WGM01)|(1<<COM01)|(1<<CS00)|(1<<CS01);/* Set Fast PWM with Fosc/64 Timer0 clock */	
	
	TIMSK = (1 << TOIE1);	/* Enable Timer1 overflow interrupts */
	TCCR1A = 0;
	
	long count;
	double distance;
	/*
	double w;
	double velocity;
	double max_distance;
	const double w_max = 11500;
	const double V_max = 6;
	const double V_in = 5;
	const double r = 0.03;
	const double g = 9.81;
	const double G = 0.0;
	const double u = 0.7;
	*/

	/* LED Intensity */
	int intensityMax;
	int intensityMin;
	int LDR = 0;
	unsigned char duty = 250;
	
	PWM_init();
	ADC_Init();
	
    while (1) 
    {	
		/* Automatic Braking System */
		   /* Give 10us trigger pulse on trig. pin to HC-SR04 */
		PORTA |= (1 << Trigger_pin);
		_delay_us(10);
		PORTA &= (~(1 << Trigger_pin));
		
		TCNT1 = 0;    	/* Clear Timer counter */
		TCCR1B = 0x41;	/* Capture on rising edge, No prescaler*/
		TIFR = 1<<ICF1;	/* Clear ICP flag (Input Capture flag) */
		TIFR = 1<<TOV1;	/* Clear Timer Overflow flag */

		   /*Calculate width of Echo by Input Capture (ICP) */
		while ((TIFR & (1 << ICF1)) == 0);/* Wait for rising edge */
		TCNT1 = 0;	      /* Clear Timer counter */
		TCCR1B = 0x01;	  /* Capture on falling edge, No prescaler */
		TIFR = 1<<ICF1;	  /* Clear ICP flag (Input Capture flag) */
		TIFR = 1<<TOV1;	  /* Clear Timer Overflow flag */
		TimerOverflow = 0;/* Clear Timer overflow count */

		while ((TIFR & (1 << ICF1)) == 0);/* Wait for falling edge */
		count = ICR1 + (65535 * TimerOverflow);	/* Take count */
		   /* 16MHz Timer freq, sound speed =343 m/s */
		distance = (double)count / 932.945;
		
		/*
		w = w_max * (V_in/V_max) * (100.0/255.0) * (2.0*(22.0/7.0)/60.0); // ((ADC_Read(1)/4)/255) * (2*(22/7)/60);
		velocity = w * r;
		max_distance = ((pow(velocity, 2))/(2.0*g*(u+G))*100.0/40.0) + 10;
		*/
		// if(distance<=max_distance){
		if(distance<=40){
			PORTC &= ~(0b00000011);
			PORTC |= (1<<5);  /* DELETE */
			OCR0 = 0;
		}
		else {
			if (Direction !=0)	/* Rotate DC motor Clockwise */
				PORTC = 1;
			else			        /* Else rotate DC motor Anticlockwise */
				PORTC = 2;
			PORTC &= ~(1<<5); /* DELETE */
			OCR0 = (ADC_Read(1)/4);
		}
		if (OCR0 == 255)
			PORTC |= (1<<2);
		else
			PORTC &= ~(1<<2);
		
		/* LED Intensity */
		if(LDR==1){
			intensityMax = 255;
			intensityMin = 100;
		}
		else{
			intensityMax = 170;
			intensityMin = 70;
		}
		
		if(distance<=40){ //&& distance>=10){
			duty = intensityMin + (intensityMax-intensityMin) * ((distance-10)/30);
			PORTC |= (1<<0);
		}
		else {
			duty = intensityMax;
			PORTC &= ~(1<<0);
		}
		OCR2 = duty;
    }
}

