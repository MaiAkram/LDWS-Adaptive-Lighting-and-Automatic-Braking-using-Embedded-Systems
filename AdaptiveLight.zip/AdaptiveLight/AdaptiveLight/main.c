/*
 * AdaptiveLight.c
 *
 * Created: 5/7/2023 2:36:25 PM
 * Author : Mai
 */  

#define F_CPU 8000000UL
#include <avr/io.h>
#include <util/delay.h>
#include <stdlib.h>

void ADC_Init()
{
	DDRA = 0x00;			    /* Make ADC port as input */
	ADCSRA = 0x87;			/* Enable ADC, fr/128  */
	ADMUX = 0x40;			/* Vref: Avcc, ADC channel: 0 */
	
}

int ADC_Read(char channel)
{
	int Ain,AinLow;
	
	ADMUX=ADMUX|(channel & 0x0f);	/* Set input channel to read */

	ADCSRA |= (1<<ADSC);		/* Start conversion */
	while((ADCSRA&(1<<ADIF))==0);	/* Monitor end of conversion interrupt */
	
	_delay_us(10);
	AinLow = (int)ADCL;		/* Read lower byte*/
	Ain = (int)ADCH*256;		/* Read higher 2 bits and 
					Multiply with weight */
	Ain = Ain + AinLow;				
	return(Ain);			/* Return digital value*/
}

 
int main()
{
	TCCR1A|=(1<<COM1A1)|(1<<WGM11);                    //NON Inverted PWM
	TCCR1B|=(1<<WGM13)|(1<<WGM12)|(1<<CS11)|(1<<CS10); //PRESCALER=64 MODE 14(FAST PWM)
	ICR1=4999;        //fPWM=50Hz (Period = 20ms Standard).
	TCNT1 = 0;		  /* Set timer1 count zero */
	DDRD|=(1<<PD5);   //PWM Pins as Out
	
	DDRB |= (1<<PB3);		/* Make OC0 pin as Output */

	TCNT0 = 0;			/* Set timer0 count zero */
	TCCR0 = (1<<WGM00)|(1<<WGM01)|(1<<COM01)|(1<<CS00)|(1<<CS01);/* Set Fast PWM with Fosc/64 Timer0 clock */
	
	int DC2 = 150;
	
	int steering;
	ADC_Init();

	while(1)
	{
		OCR0 = (ADC_Read(1)/4);
		if (OCR0 > DC2){
			steering = OCR0 - DC2;
			OCR1A = 130 + (350-130)*(steering/255);
		}
		else if (OCR0 <= DC2){
			steering = DC2 - OCR0;
			OCR1A = 350 + (600-350)* (steering/255);
		}
		else{}
	}
	return 0;
}



