/*
 * MC.c
 *
 * Created: 5/9/2023 3:20:49 AM
 * Author : Mai
 */ 

#define F_CPU 16000000UL
#include <avr/io.h>
#include <util/delay.h>
#include <stdlib.h>
#include <avr/interrupt.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

/* LDWS */
#define BLUE_PIN PC2
#define BUZZER_PIN PC5   // Buzzer connected to PC5
#define LED_PIN    PC3   // LED connected to PB0
#define SWITCH_PIN PA5   // switch connected to PA5

/* Automatic Braking System */
#define  Trigger_pin	PA0	/* Defining Trigger pin */
int TimerOverflow = 0;
volatile uint8_t Direction = 0;

/* DC Motor Speed ADC Setting */
void ADC_Init()				/* ADC Initialization function */
{
	DDRA = 0x01;			/* Make ADC port as input */
	ADCSRA = 0x87;			/* Enable ADC, with freq/128 */
	ADMUX = 0x40;			/* Vref: Avcc, ADC channel: 0 */
}
int ADC_Read(char channel)		     /* ADC Read function */
{
	ADMUX = 0x40 | (channel & 0x07);
	ADCSRA |= (1<<ADSC);		     /* ADC conversion started */
	while (!(ADCSRA & (1<<ADIF)));	 /* Loop until end of conversion */
	ADCSRA |= (1<<ADIF);		     /* Interrupt flag Cleared */
	_delay_ms(1);
	return ADCW;
}

/* Rotational Direction Reversal on Interrupt */
ISR(INT0_vect)
{
	Direction = ~Direction; /* Direction Change */
	_delay_ms(50);			/* De-bouncing delay */
}

/* Ultrasonic pulse Timer 1 Interrupt */
ISR(TIMER1_OVF_vect)
{
	TimerOverflow++;	    /* Increment Timer Overflow count */
}

/* LED Intensity PWM Function */
void PWM_init()
{
	/*set LED Intensity Input as fast PWM mode with non-inverted output*/
	TCCR2 = (1<<WGM00) | (1<<WGM01) | (1<<COM01) | (1<<CS00);
	DDRD|=(1<<PD7);         /* set OC2 pin as output */
}

int main(void)
{	
	/* LDWS PORTS */
	DDRC |= (1 << LED_PIN);
	DDRC |= (1 << BUZZER_PIN);
	DDRA &= ~(1 << SWITCH_PIN);
	PORTA |= (1 << SWITCH_PIN); // Enable pull-up resistor on switch pin
	
	/* Automatic Braking System PORTS */
	DDRD &= ~(1<<PD2);		/* Make INT0 pin as Input  */	
	DDRA = 0x01;		    /* Make trigger pin as output */
	DDRB |= (1<<PB3);		/* Make OC0 pin as Output for DC Motor Enable Pin */
	DDRC = 0xFF;			/* Make PORTC as Output Port for DC Motor Input Pins */
	PORTC = 0x00;
	PORTD |= (1<<PD2);		/* Pull-up */
	
	GICR = (1<<INT0);		/* Enable INT0*/
	MCUCR = ((1<<ISC00)|(1<<ISC01)); /* INT0 on Rising Edge enabled for changing motor direction */
	sei();			    	/* Global Interrupts Enabled */
	
	TCNT0 = 0;			    /* No loaded Timer0 value */
	TCCR0 = (1<<WGM00)|(1<<WGM01)|(1<<COM01)|(1<<CS00)|(1<<CS01); /* Set DC Motor input as Fast PWM, non-inverted output, with a 64 pre-scaler Timer0 clock */	
	
	TIMSK = (1 << TOIE1);	/* Timer1 overflow interrupts enabled */
	TCCR1A = 0;
	
	long count;
	double distance;
	
	/* Maximum distance calculation variables */
	double w;
	double PWM;
	double velocity;
	double max_distance;
	const double w_max = 11500;
	const double V_max = 6;
	const double V_in = 5;
	const double r = 0.03;
	const double g = 9.81;
	const double G = 0.0;
	const double u = 0.7;
	

	/* LED Intensity Variables */
	int intensityMax;
	int intensityMin;
	int LDR = 0;
	unsigned char duty = 250;
	
	PWM_init();
	ADC_Init();
	
    while (1) 
    {	
		/* Automatic Braking System Operation */
		   /* Giving a 10 us Pulse through the ultrasonic trigger pin */
		PORTA |= (1 << Trigger_pin);
		_delay_us(10);
		PORTA &= (~(1 << Trigger_pin));
		
		TCNT1 = 0;    	/* No loaded Timer/Counter1 value */
		TCCR1B = 0x41;	/* Waiting for pulse rising edge */
		TIFR = 1<<ICF1;	/* Clear Timer Flags */
		TIFR = 1<<TOV1;

		   /* Pulse return timing measurement */
		while ((TIFR & (1 << ICF1)) == 0);/* Wait for rising edge */
		TCNT1 = 0;	       /* No loaded Timer/Counter1 value */
		TCCR1B = 0x01;	   /* Falling edge detection, No pre-scaler Timer/Counter parameters */
		TIFR = 1<<ICF1;	   /* Clear Timer flags */
		TIFR = 1<<TOV1;
		TimerOverflow = 0; /* Reseting the count, waiting for a new one */

		while ((TIFR & (1 << ICF1)) == 0);      /* Waiting for receiving the sent pulse falling edge */
		count = ICR1 + (65535 * TimerOverflow);	/* Count pulse return time: Number of overflows multiplied by time for overflow to happen */
		   /* Speed of Sound =343 m/s */
		distance = (double)count / 932.945;
		
		
		PWM = (ADC_Read(1)/4);
		w = w_max * (V_in/V_max) * (PWM/255.0) * (2.0*(22.0/7.0)/60.0);
		velocity = w * r;
		max_distance = ((pow(velocity, 2))/(2.0*g*(u+G))*100.0/40.0) + 10;
		
		if(distance<=max_distance){
		//if(distance<=40){
			PORTC &= ~(0b00000011);
			PORTC |= (1<<5);
			OCR0 = 0;
		}
		else {
			if (Direction !=0)	    /* Retain Motors Direction of Rotaion */
				PORTC = 1;
			else
				PORTC = 2;
			PORTC &= ~(1<<5);
			OCR0 = (ADC_Read(1)/4);
		}
		if (OCR0 == 255)
			PORTC |= (1<<2);
		else
			PORTC &= ~(1<<2);
		
		/* LED Intensity Operation */
		if(LDR==1){
			intensityMax = 255;
			intensityMin = 100;
		}
		else{
			intensityMax = 170;
			intensityMin = 70;
		}
		
		if(distance<=50){
			duty = intensityMin + (intensityMax-intensityMin) * ((distance-10)/40);
		}
		else {
			duty = intensityMax;
		}
		OCR2 = duty;
		
		/* LDWS Operation */
		if (PINA & (1 << SWITCH_PIN))    // check switch state
		{
			PORTC &= ~(1 << LED_PIN);    // turn off LED
			PORTC &= ~(1 << BUZZER_PIN);
			PORTC |= (1 <<  BLUE_PIN);   // turn on LED
		}
		else
		{
			PORTC |= (1 << LED_PIN);     // turn on LED
			PORTC |= (1 <<  BUZZER_PIN); // turn on Buzzer
			PORTC &= ~(1 << BLUE_PIN);
		}
    }
	return 0;
}



