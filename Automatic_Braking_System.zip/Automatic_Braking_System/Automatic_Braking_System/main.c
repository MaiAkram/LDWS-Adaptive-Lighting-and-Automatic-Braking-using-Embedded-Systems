/*
 * Automatic_Braking_System.c
 *
 * Created: 4/25/2023 3:37:15 PM
 * Author : Mai
 */ 

#define F_CPU 8000000UL			/* Define CPU Frequency 8MHz */
#include <avr/io.h>			/* Include AVR std. library file */
#include <avr/interrupt.h>
#include <stdio.h>			/* Include std. library file */
#include <util/delay.h>			/* Include Delay header file */
#include <string.h>
#include <stdlib.h>
#include <math.h>

#define  Trigger_pin	PA0	/* Trigger pin */

int TimerOverflow = 0;

volatile uint8_t Direction = 0;

void ADC_Init()				/* ADC Initialization function */
{
	DDRA = 0x01;			/* Make ADC port as input */
	ADCSRA = 0x87;			/* Enable ADC, with freq/128 */
	ADMUX = 0x40;			/* Vref: Avcc, ADC channel: 0 */
}

int ADC_Read(char channel)		/* ADC Read function */
{
	ADMUX = 0x40 | (channel & 0x07);/* set input channel to read */
	ADCSRA |= (1<<ADSC);		    /* Start ADC conversion */
	while (!(ADCSRA & (1<<ADIF)));	/* Wait until end of conversion */
	ADCSRA |= (1<<ADIF);		    /* Clear interrupt flag */
	_delay_ms(1);			        /* Wait a little bit */
	return ADCW;			        /* Return ADC word */
}

ISR(INT0_vect)
{
	Direction = ~Direction;		/* Toggle Direction */
	_delay_ms(50);			/* Software de-bouncing control delay */
}

ISR(TIMER1_OVF_vect)
{
	TimerOverflow++;	/* Increment Timer Overflow count */
}

int main(void)
{
	// char string[10];
	long count;
	double distance;
	/*
	double w;
	double velocity;
	double max_distance;
	
	const double w_max = 11500;
	const double V_max = 6;
	const double V_in = 5;
	const double r = 0.03;
	const double g = 9.81;
	const double G = 0.05;
	const double u = 0.7;
	*/
	DDRA = 0x01;		/* Make trigger pin as output */
	DDRD = 0x00;
	DDRC = 0xFF;
	PORTC = 0x00;
	PORTD = 0xFF;		/* Turn on Pull-up */
	
	// LCD_Init();
	// LCD_String_xy(1, 0, "Ultrasonic");	
	
	// DDRC = 0xFF;			/* Make PORTC as output Port */
	// DDRD &= ~(1<<PD2);		/* Make INT0 pin as Input */
	
	DDRB |= (1<<PB3);		/* Make OC0 pin as Output */
	GICR = (1<<INT0);		/* Enable INT0*/
	MCUCR = ((1<<ISC00)|(1<<ISC01));/* Trigger INT0 on Rising Edge triggered */
	sei();				/* Enable Global Interrupt */
	ADC_Init();			/* Initialize ADC */
	TCNT0 = 0;			/* Set timer0 count zero */
	TCCR0 = (1<<WGM00)|(1<<WGM01)|(1<<COM01)|(1<<CS00)|(1<<CS01);/* Set Fast PWM with Fosc/64 Timer0 clock */
		
	TIMSK = (1 << TOIE1);	/* Enable Timer1 overflow interrupts */
	TCCR1A = 0;
	
	while(1)
	{
		//if (Direction !=0)	/* Rotate DC motor Clockwise */
		//	PORTC = 1;
		//else			    /* Else rotate DC motor Anticlockwise */
		//	PORTC = 2;
		//OCR0 = (ADC_Read(1)/4);	/* Read ADC and map it into 0-255 to write in OCR0 register */
		if ((ADC_Read(1)/4) == 255)
			PORTC |= 4;
		else
			PORTC &= ~(4);
		
		/* Give 10us trigger pulse on trig. pin to HC-SR04 */
		PORTA |= (1 << Trigger_pin);
		_delay_us(10);
		PORTA &= (~(1 << Trigger_pin));
		
		TCNT1 = 0;    	/* Clear Timer counter */
		TCCR1B = 0x41;	/* Capture on rising edge, No prescaler*/
		TIFR = 1<<ICF1;	/* Clear ICP flag (Input Capture flag) */
		TIFR = 1<<TOV1;	/* Clear Timer Overflow flag */

		/*Calculate width of Echo by Input Capture (ICP) */
		
		while ((TIFR & (1 << ICF1)) == 0);/* Wait for rising edge */
		TCNT1 = 0;	/* Clear Timer counter */
		TCCR1B = 0x01;	/* Capture on falling edge, No prescaler */
		TIFR = 1<<ICF1;	/* Clear ICP flag (Input Capture flag) */
		TIFR = 1<<TOV1;	/* Clear Timer Overflow flag */
		TimerOverflow = 0;/* Clear Timer overflow count */

		while ((TIFR & (1 << ICF1)) == 0);/* Wait for falling edge */
		count = ICR1 + (65535 * TimerOverflow);	/* Take count */
		/* 16MHz Timer freq, sound speed =343 m/s */
		distance = (double)count / 932.945;
		
		/*
		w = w_max * (V_in/V_max) * (100.0/255.0) * (2.0*(22.0/7.0)/60.0); // ((ADC_Read(1)/4)/255) * (2*(22/7)/60);
		velocity = w * r;
		max_distance = ((pow(velocity, 2))/(2.0*g*(u+G))*100.0/40.0) + 10;
		*/
		// if(distance<=max_distance){
		if(distance<=30){
			PORTC &= ~(0b00000011);
			PORTC |= (1<<0);
			OCR0 = 0;
		}
		else {
			if (Direction !=0)	/* Rotate DC motor Clockwise */
				PORTC = 1;
			else			    /* Else rotate DC motor Anticlockwise */
				PORTC = 2;
			OCR0 = (ADC_Read(1)/4);
		}
	}
}


